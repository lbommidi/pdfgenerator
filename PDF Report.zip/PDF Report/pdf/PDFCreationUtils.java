package com.ge.partstrack.reportbuilder.pdf;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.BaseFont;

public class PDFCreationUtils {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(PDFCreationUtils.class);

	public static final BaseColor BASE_COLOR_BLUE = new BaseColor(84, 141, 212);
	public static final BaseColor BASE_COLOR_GREY = new BaseColor(235, 235, 235);
	public static final BaseColor BASE_COLOR_LIGHT_GREY = new BaseColor(246,
			246, 246);

	public static final Font NORMAL_FONT_TABLE_CELL_12 = new Font(
			getGEInspiraRegularFont(), 12, Font.NORMAL, new BaseColor(128, 128,
					128));
	public static final Font NORMAL_FONT_TABLE_CELL_10 = new Font(
			getGEInspiraRegularFont(), 10, Font.NORMAL, new BaseColor(128, 128,
					128));
	public static final Font NORMAL_FONT_14 = new Font(
			getGEInspiraRegularFont(), 14, Font.NORMAL);
	public static final Font NORMAL_FONT_CUSTOM_14 = new Font(
			getGEInspiraRegularFont(), 14, Font.NORMAL, BASE_COLOR_BLUE);
	public static final Font NORMAL_FONT_TABLE_CELL_HEADER_10 = new Font(
			getGEInspiraRegularFont(), 10, Font.NORMAL, new BaseColor(128, 128,
					128));

	public static final Font NORMAL_FONT_16 = new Font(
			getGEInspiraRegularFont(), 16, Font.NORMAL);
	public static final Font BOLD_FONT_CUSTOM_16 = new Font(
			getGEInspiraRegularFont(), 16, Font.NORMAL, BASE_COLOR_BLUE);
	public static final Font NORMAL_FONT_12 = new Font(
			getGEInspiraRegularFont(), 12, Font.NORMAL);

	public static final Font NORMAL_FONT_TABLE_CELL_8 = new Font(
			getGEInspiraRegularFont(), 8, Font.NORMAL, new BaseColor(128, 128,
					128));
	public static final Font BOLD_FONT_TABLE_CELL_HEADER_10 = new Font(
			getGEInspiraRegularFont(), 10, Font.BOLD, new BaseColor(128, 128,
					128));

	public static BaseFont getGEInspiraRegularFont() {
		BaseFont base = null;
		try {
			base = BaseFont.createFont("reportbuilder/fonts/GEInspRg.ttf",
					BaseFont.WINANSI, true);

		} catch (Exception e) {
			LOGGER.error(
					"Excepton occured while getting GE font" + e.getMessage(),
					e);
		}
		return base;
	}

	public static BaseFont getGEInspiraMediumFontFile() {
		BaseFont base = null;
		try {
			base = BaseFont.createFont("reportbuilder/fonts/GEInspRg.ttf",
					BaseFont.WINANSI, true);
		} catch (Exception e) {
			LOGGER.error(
					"Excepton occured while getting GE font" + e.getMessage(),
					e);
		}
		return base;
	}

	public static final Font getGEInspiraMediumFont(int fontSize, int style,
			BaseColor color) {
		if (color != null) {
			return new Font(getGEInspiraMediumFontFile(), fontSize, style,
					color);
		} else {
			return new Font(getGEInspiraMediumFontFile(), fontSize, style);
		}
	}

}
