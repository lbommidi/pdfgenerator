package com.ge.partstrack.reportbuilder.pdf;

import lombok.Data;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;

@Data
public class PDFTableCell {

    private Document document;
    private PdfPTable table;
    private String cellText;
    private Font cellTextFont;
    private int border;
    private int cellBorder;
    private int leftPadding;
    private int topPadding;
    private int bottomPadding;
    private BaseColor color;
    private int colSpan;
    private int cellTextAlignment;
    private boolean headerRow;
}
