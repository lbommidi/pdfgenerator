package com.ge.partstrack.reportbuilder.pdf;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.rmi.ServerException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.partstrack.manager.EventManager;
import com.ge.partstrack.manager.OperationalDataManager;
import com.ge.partstrack.models.LCDValidationStatus;
import com.ge.partstrack.models.Pipo;
import com.ge.partstrack.models.PipoPart;
import com.ge.partstrack.models.PipoPartStatus;
import com.ge.partstrack.models.PipoPartValidationStatus;
import com.ge.partstrack.reportbuilder.dto.IndexContent;
import com.ge.partstrack.reportbuilder.dto.IndexContents;
import com.ge.partstrack.reportbuilder.dto.ReportSectionConfig;
import com.ge.partstrack.reportbuilder.error.ReportBuilderErrorInfo;
import com.ge.partstrack.reportbuilder.utils.ReportBuilderUtils;
import com.ge.partstrack.reportbuilder.utils.ReportConstants;
import com.ge.partstrack.rsa.postgres.PipoPartRepository;
import com.ge.partstrack.rsa.postgres.PipoRepository;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.DottedLineSeparator;

@Component
public class PDFHelper {

    private static final int DEFAULT_TITLE_INDEND = 0;
    private static final int DEFAULT_TITLE_SPACING_BEFORE = 5;
    private static final int DEFAULT_TITLE_SPACING_AFTER = 5;
    private static final int DEFAULT_PARAGRAPH_INDEND = 20;

    public static final String CONTENTS = "Contents";

    private static final String COVER_FOOTER_TEXT = "This report may contain Confidential and Proprietary information subject to a confidentiality agreement.";

    private static final String EFSR_ID = "PIPO Report EFSR ID#: ";
    private static final String UNIT_NAME = "Unit Name: ";

    BaseFont baseFont;
    Font chapterFont = FontFactory.getFont(FontFactory.HELVETICA, 24,
            Font.NORMAL);

    @Value("${reportbuilder.ge.logo.path}")
    private String logoPath;

    @Value("${reportbuilder.ge.cover.logo.path}")
    private String logoImage;

    private static final Logger LOGGER = LoggerFactory
            .getLogger(PDFHelper.class);

    @Autowired
    OperationalDataManager operationalDataManager;

    @Autowired
    EventManager eventManager;

    @Autowired
    PipoRepository pipoRepository;

    @Autowired
    PipoPartRepository pipoPartRepository;

    @Autowired
    private ReportSectionConfig reportSectionConfig;

    private IndexContents smartReportIndex;
    private Document document;
    private PdfWriter pdfWriter;
    PDFHeaderFooter headerFooterEvent = new PDFHeaderFooter();

    int indexPageCount = 1;

    public File createPDF(Long eventId) throws IOException {

		File finalFile = new File(eventId + "_Event_Report_"+ System.currentTimeMillis() + ReportConstants.PDF_EXTENSION);
		File tmpFile = new File("Event_Report_"+System.currentTimeMillis()+ReportConstants.PDF_EXTENSION);

        try {
            smartReportIndex = new IndexContents();
            document = new Document(PageSize.A4);

            // Configure PDF Writer
            pdfWriter = PdfWriter.getInstance(document,
                    new FileOutputStream(tmpFile));
            pdfWriter.setBoxSize("art", PageSize.A4);
            pdfWriter.setFullCompression();
            pdfWriter.setPageEvent(headerFooterEvent);
            document.open();

            // create PDf Cover Page
            generatePDFCoverPage(eventId);

            generatePipoScopeList(eventId);

            // create Index Page
            addIndexPage();

            indexPageCount += 1;
            document.newPage();
            pdfWriter.setPageEvent(headerFooterEvent);
            headerFooterEvent.setIndexPageCount(indexPageCount);

            // Done creating temporary report
            document.close();

            createFinalCRTFile(tmpFile, finalFile, indexPageCount);
            
            return finalFile;

        } catch (FileNotFoundException e) {
            LOGGER.error(ReportBuilderUtils.getCurrentMethodName(), e);
            throw new ServerException(
                    ReportBuilderErrorInfo.ERRMSG_IO_EXCEPTION);
        } catch (DocumentException e) {
            LOGGER.error(ReportBuilderUtils.getCurrentMethodName(), e);
            throw new ServerException(
                    ReportBuilderErrorInfo.ERRMSG_CRT_PDF_CREATION);
        }

    }

    private void generatePipoScopeList(Long eventId)
            throws DocumentException {
        if (reportSectionConfig
                .isSectionEnabled(ReportSectionConfig.TIMERS_COUNTERS)) {
            generateTimersAndCounterSection(eventId);
        }

        Iterator<Entry<Pipo, List<PipoPart>>> list = getChildParts(eventId)
                .entrySet().iterator();
        while (list.hasNext()) {

            Entry<Pipo, List<PipoPart>> entry = list.next();
            String kksnr = entry.getKey().getKksnr();
            String cotxt = entry.getKey().getCotxt();

            if (reportSectionConfig.isSectionEnabled(kksnr + cotxt)) {
                generateLTPVanePage(eventId, kksnr, cotxt,
                        entry.getValue());
            }
        }
    }

    private void generateTimersAndCounterSection(Long eventId)
            throws DocumentException {
        IndexContent index = new IndexContent(
                smartReportIndex.getNextIndex());
        smartReportIndex.add(index);
        sectionTitle(index, ReportConstants.TIMERS_COUNTERS,
                pdfWriter.getPageNumber());

        PDFTableCell cellAttributes;
        PDFTableCell cellDataAttributes;
        
        PdfPTable table = createTable(2, 0);
        table.setWidthPercentage(60);
        table.setHorizontalAlignment(Element.ALIGN_LEFT);

        cellAttributes = getHeaderCellAttributes(table);
		
		cellDataAttributes = getDataCellAttributes(table);
        
        cellAttributes.setCellText(ReportConstants.OPT_DATA_COUNTER);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(ReportConstants.READING);
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.EQUI_OPT_HOURS);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(operationalDataManager.getOperationalData(eventId) != null
                        ? String.valueOf(operationalDataManager
                                .getOperationalData(eventId).getEoh())
                        : "");
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.OPT_HOURS);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(
                operationalDataManager.getOperationalData(eventId) != null
                        ? String.valueOf(operationalDataManager
                                .getOperationalData(eventId)
                                .getOperationalHours())
                        : "");
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.OPT_HOURS_BACKUP);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(
                operationalDataManager.getOperationalData(eventId) != null
                        ? String.valueOf(operationalDataManager
                                .getOperationalData(eventId)
                                .getOperatonalHoursOnBackup())
                        : "");
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.OPT_STARTS);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(
                operationalDataManager.getOperationalData(eventId) != null
                        ? String.valueOf(operationalDataManager
                                .getOperationalData(eventId).getStarts())
                        : "");
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.OPT_STARTS_BACKUP);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(
                operationalDataManager.getOperationalData(eventId) != null
                        ? String.valueOf(operationalDataManager
                                .getOperationalData(eventId)
                                .getStartsOnBackup())
                        : "");
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.OPT_TRIPS);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(
                operationalDataManager.getOperationalData(eventId) != null
                        ? String.valueOf(operationalDataManager
                                .getOperationalData(eventId).getTrips())
                        : "");
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.OPT_TRIPS_HIGH);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(
                operationalDataManager.getOperationalData(eventId) != null
                        ? String.valueOf(operationalDataManager
                                .getOperationalData(eventId)
                                .getTripsHigh())
                        : "");
        createCellWithStyle(cellDataAttributes);

        document.add(table);
    }

    private void generatePartinAndPartsoutReport(Long eventId)
            throws DocumentException {

        PDFTableCell cellAttributes;
        PDFTableCell cellDataAttributes;
        
        PdfPTable table = createTable(2, 0);
        table.setWidthPercentage(60);
        table.setHorizontalAlignment(Element.ALIGN_MIDDLE);

        cellAttributes = getHeaderCellAttributes(table);
        cellDataAttributes = getDataCellAttributes(table);
        
        cellAttributes.setCellText(ReportConstants.REPORT_NO);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getEfsrId());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.PLANT_NAME);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getPalantName());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.UNIT_NAME);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getUnitName());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.UNIT_KEY);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getUnitKey());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.EVENT_NAME);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getEventName());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.INSPECT_CODE);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getInspectionCode());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.OUTAGE_TYPE);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getOutageType());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.DESCRIPTION);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getDescription());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.COUNTRY);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getCountry());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.CITY);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(
                eventManager.getEvent(String.valueOf(eventId)).getCity());
        createCellWithStyle(cellDataAttributes);

        cellAttributes.setCellText(ReportConstants.SYSTEM_ID);
        createCellWithStyle(cellAttributes);

        cellDataAttributes.setCellText(eventManager
                .getEvent(String.valueOf(eventId)).getSystemId());
        createCellWithStyle(cellDataAttributes);

        document.add(table);
    }

    private void generateLTPVanePage(Long eventId, String kksnr,
            String cotxt, List<PipoPart> pipoPartList)
            throws DocumentException {

        IndexContent index = new IndexContent(
                smartReportIndex.getNextIndex());
        smartReportIndex.add(index);

        sectionTitle(index, kksnr + " - " + cotxt,
                pdfWriter.getPageNumber());

        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(120f);
        table.setTotalWidth(new float[] { 15, 22, 30, 22, 30, 18 });

        PDFTableCell cellAttributes = getHeaderCellAttributes(table);;
		
		PDFTableCell cellDataAttributes;
		
		cellAttributes.setCellText("");
		createCellWithStyle(cellAttributes);
		
		cellAttributes.setCellText(ReportConstants.PARTS_OUT);
		cellAttributes.setCellTextAlignment(Element.ALIGN_CENTER);
		cellAttributes.setColSpan(2);
		createCellWithStyle(cellAttributes);

		cellAttributes.setCellText(ReportConstants.PARTS_IN);
		cellAttributes.setCellTextAlignment(Element.ALIGN_CENTER);
		cellAttributes.setColSpan(3);
		createCellWithStyle(cellAttributes);

		cellAttributes.setCellText(ReportConstants.LOCATION_NO);
		cellAttributes.setColSpan(0);
		createCellWithStyle(cellAttributes);
		
		cellAttributes.setCellText(ReportConstants.SERIAL_NO);
		cellAttributes.setColSpan(0);
		createCellWithStyle(cellAttributes);
		
		cellAttributes.setCellText(ReportConstants.IDENT_NO);
		cellAttributes.setColSpan(0);
		createCellWithStyle(cellAttributes);
		
		cellAttributes.setCellText(ReportConstants.SERIAL_NO);
		cellAttributes.setColSpan(0);
		createCellWithStyle(cellAttributes);
		
		cellAttributes.setCellText(ReportConstants.IDENT_NO);
		cellAttributes.setColSpan(0);
		createCellWithStyle(cellAttributes);
		
		cellAttributes.setCellText(ReportConstants.PART_CONDITION);
		cellAttributes.setColSpan(0);
		createCellWithStyle(cellAttributes);
		
		cellDataAttributes = getDataCellAttributes(table);

		Map<String, List<PipoPart>> pipoPartWithLocation = pipoPartList.stream().filter(key -> key!=null).collect(Collectors.groupingBy(PipoPart::getValidatedPartPosition));
		List<Integer> keys = new ArrayList<>();
		for (String key : pipoPartWithLocation.keySet()) {
			keys.add(Integer.parseInt(key));
		}
		Collections.sort(keys);
		keys.forEach((key)->{
        	
        	cellDataAttributes.setCellText(key+"");
			createCellWithStyle(cellDataAttributes);
        	
        	if(pipoPartWithLocation.get(key+"").size()>1){
        		
        		pipoPartWithLocation.get(key+"").forEach(pipoPart->{
            		if(pipoPart.getPartStatus().equals(PipoPartStatus.PART_OUT)){
            			
            			cellDataAttributes.setCellText(pipoPart.getValidatedSerialNumber());
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText(pipoPart.getValidatedPartNumber());
            			createCellWithStyle(cellDataAttributes);
            			
            		}
            	});
        		pipoPartWithLocation.get(key+"").forEach(pipoPart->{
            		if(pipoPart.getPartStatus().equals(PipoPartStatus.PART_IN)){
            			
            			cellDataAttributes.setCellText(pipoPart.getValidatedSerialNumber());
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText(pipoPart.getValidatedPartNumber());
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText(pipoPart.getValidatedPartCondition());
            			createCellWithStyle(cellDataAttributes);
            			
            		}
            	});
        	}else{
        		pipoPartWithLocation.get(key+"").forEach(pipoPart->{
            		if(pipoPart.getPartStatus().equals(PipoPartStatus.PART_OUT)){
            			cellDataAttributes.setCellText(pipoPart.getValidatedSerialNumber());
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText(pipoPart.getValidatedPartNumber());
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText("NA");
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText("NA");
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText("NA");
            			createCellWithStyle(cellDataAttributes);
            		}
            	});
        		pipoPartWithLocation.get(key+"").forEach(pipoPart->{
            		if(pipoPart.getPartStatus().equals(PipoPartStatus.PART_IN)){
            			cellDataAttributes.setCellText("NA");
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText("NA");
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText(pipoPart.getValidatedSerialNumber());
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText(pipoPart.getValidatedPartNumber());
            			createCellWithStyle(cellDataAttributes);
            			
            			cellDataAttributes.setCellText(pipoPart.getValidatedPartCondition());
            			createCellWithStyle(cellDataAttributes);
            		}
            	});
        	}
        	
        });
        try {
            document.add(table);
        } catch (Exception e) {
        }
    }

    private void generatePDFCoverPage(Long eventId)
            throws DocumentException, ServerException {

        pdfWriter.setPageEvent(null);
        document.setMargins(ReportConstants.MARGIN_10,
                ReportConstants.MARGIN_20, ReportConstants.MARGIN_0,
                ReportConstants.MARGIN_100);

        document.newPage();

        createImage(logoImage);

        document.add(Chunk.NEWLINE);

        String efsrId = eventManager.getEvent(String.valueOf(eventId))
                .getEfsrId();
        createCustomParagraph(EFSR_ID + efsrId,
                PDFCreationUtils.NORMAL_FONT_16, Element.ALIGN_CENTER, 0);

        document.add(Chunk.NEWLINE);

        String unitName = eventManager.getEvent(String.valueOf(eventId))
                .getUnitName();

        createCustomParagraph(UNIT_NAME + unitName,
                PDFCreationUtils.NORMAL_FONT_16, Element.ALIGN_CENTER, 0);

        document.add(Chunk.NEWLINE);

        generatePartinAndPartsoutReport(eventId);

        PdfPTable table = new PdfPTable(ReportConstants.TABLE_2_COLUMNS);

        table = new PdfPTable(ReportConstants.TABLE_2_COLUMNS);
        table.setTotalWidth(document.getPageSize().getWidth());

        table.setHeaderRows(1);
        table.setWidthPercentage(ReportConstants.COLUMNS_WIDTH_100);

        createCell(table, COVER_FOOTER_TEXT,
                ReportConstants.CELL_LEFT_PADDING_40, 2);

        table.writeSelectedRows(0, -1, 0, table.getTotalHeight() + 18,
                pdfWriter.getDirectContent());
    }

    public void createImage(String imagePath) {
        Image image;
        try {
            image = Image.getInstance(
                    getClass().getClassLoader().getResource(imagePath));
            document.add(image);
        } catch (BadElementException | IOException e) {
            LOGGER.error("I/O Excepton occured while creating images"
                    + e.getMessage(), e);
        } catch (DocumentException e) {
            LOGGER.error("Document Excepton occured while creating images"
                    + e.getMessage(), e);
        }

    }

    private void sectionTitle(IndexContent index, String heading,
            final int pageNumber) throws DocumentException {
        sectionTitle(index, heading, pageNumber, 0);
    }

    private void sectionTitle(IndexContent index, String heading,
            final int pageNumber, int level) throws DocumentException {

        // check if new page is needed for the section
        pdfWriter.setPageEvent(headerFooterEvent);
        setDefaultPageMargin();
        index.setHeadingLevel(level);
        index.setContentVisible(true);
        index.setHeading(heading);
        index.setPageNumber(pageNumber);

        // heading level for components
        Chunk pageTitle = null;
        if (level != 0) {            
            pageTitle = new Chunk(ReportBuilderUtils.appendStrings(index.getHeadingString(heading)),
                    PDFCreationUtils.getGEInspiraMediumFont(18, Font.NORMAL, null));
        } else {
            document.newPage();
            pageTitle = new Chunk(ReportBuilderUtils.appendStrings(index.getHeadingString(heading)),
                    PDFCreationUtils.getGEInspiraMediumFont(ReportConstants.FONT_CONSTANT_14, Font.NORMAL,
                            new BaseColor(ReportConstants.COLOR_CONSTANT_84, ReportConstants.COLOR_CONSTANT_141,
                                    ReportConstants.COLOR_CONSTANT_212)));
        }

        pageTitle.setLocalDestination(String.valueOf(pageNumber));
        createDefaultTitleTextWithChunk(pageTitle);
    }

    public void setDefaultPageMargin() {
        document.setMarginMirroring(true);
        document.setMargins(ReportConstants.MARGIN_70,
                ReportConstants.MARGIN_70, ReportConstants.MARGIN_70,
                ReportConstants.MARGIN_100);
    }

    public void createDefaultTitleTextWithChunk(Chunk data)
            throws DocumentException {
        Paragraph paraContent = new Paragraph(data);
        paraContent.setAlignment(Element.ALIGN_LEFT);
        paraContent.setFirstLineIndent(DEFAULT_TITLE_INDEND);
        paraContent.setSpacingBefore(DEFAULT_TITLE_SPACING_BEFORE);
        paraContent.setSpacingAfter(DEFAULT_TITLE_SPACING_AFTER);
        document.add(paraContent);
    }

    private PdfPTable createTable(int columns, int headerRows) {
        return createTable(columns, headerRows, 100);
    }

    private PdfPTable createTable(int columns, int headerRows, int width) {
        PdfPTable table = new PdfPTable(columns);
        table.setHeaderRows(headerRows);
        table.setWidthPercentage(width);
        table.setSpacingBefore(15);
        table.setSpacingAfter(15);
        return table;
    }

    private PDFTableCell getHeaderCellAttributes(PdfPTable table) {
        PDFTableCell cellAttributes = new PDFTableCell();
        cellAttributes.setDocument(document);
        cellAttributes.setTable(table);
        cellAttributes.setCellTextFont(
                PDFCreationUtils.NORMAL_FONT_TABLE_CELL_HEADER_10);
        cellAttributes.setLeftPadding(ReportConstants.CELL_LEFT_PADDING_5);
        cellAttributes
                .setTopPadding(ReportConstants.CELL_TOP_BOTTOM_PADDING_5);
        cellAttributes.setBottomPadding(
                ReportConstants.CELL_TOP_BOTTOM_PADDING_5);
        cellAttributes.setCellTextAlignment(Element.ALIGN_UNDEFINED);
        cellAttributes.setHeaderRow(true);
        return cellAttributes;
    }

    private PDFTableCell getDataCellAttributes(PdfPTable table) {
        PDFTableCell cellAttributes = new PDFTableCell();
        cellAttributes.setDocument(document);
        cellAttributes.setTable(table);
        cellAttributes.setCellTextFont(
                PDFCreationUtils.NORMAL_FONT_TABLE_CELL_10);
        cellAttributes.setLeftPadding(ReportConstants.CELL_LEFT_PADDING_5);
        cellAttributes
                .setTopPadding(ReportConstants.CELL_TOP_BOTTOM_PADDING_5);
        cellAttributes.setBottomPadding(
                ReportConstants.CELL_TOP_BOTTOM_PADDING_5);
        cellAttributes.setCellTextAlignment(Element.ALIGN_UNDEFINED);
        cellAttributes.setHeaderRow(false);
        return cellAttributes;
    }

    public void createCellWithStyle(PDFTableCell cellAttributes) {
        createCellWithStyle(cellAttributes, true);
    }

    public void createCellWithStyle(PDFTableCell cellAttributes,
            boolean includeBorder) {
        PdfPCell cell;
        cell = new PdfPCell(new Phrase(cellAttributes.getCellText(),
                cellAttributes.getCellTextFont()));
        cell.setPaddingLeft(cellAttributes.getLeftPadding());
        cell.setPaddingTop(cellAttributes.getTopPadding());
        cell.setPaddingBottom(cellAttributes.getBottomPadding());
        cell.setColspan(cellAttributes.getColSpan());
        cell.setHorizontalAlignment(cellAttributes.getCellTextAlignment());
        cell.setNoWrap(false);

        if (includeBorder) {
            cell.setBorderColor(PDFCreationUtils.BASE_COLOR_LIGHT_GREY);
            cell.setBorder(Rectangle.BOX);
        } else {
            cell.setBorder(Rectangle.NO_BORDER);
        }

        if (cellAttributes.isHeaderRow()) {
            cell.setBackgroundColor(PDFCreationUtils.BASE_COLOR_GREY);
        } else {
            cell.setBackgroundColor(
                    PDFCreationUtils.BASE_COLOR_LIGHT_GREY);
        }
        cellAttributes.getTable().addCell(cell);
    }

    public void createCell(PdfPTable table, String phrase,
            int topBottomPadding, int colSpan) {
        PdfPCell cell;
        cell = new PdfPCell(
                new Phrase(phrase, PDFCreationUtils.NORMAL_FONT_12));
        cell.setPaddingLeft(topBottomPadding);
        cell.setPaddingTop(topBottomPadding);
        cell.setPaddingBottom(topBottomPadding);
        cell.setColspan(colSpan);
        cell.setBorder(Rectangle.NO_BORDER);
        table.addCell(cell);
    }

    public void createCustomParagraph(String data, Font font,
            int alignment, int spacing) throws DocumentException {
        Paragraph paraContent = new Paragraph(data, font);
        paraContent.setAlignment(alignment);
        paraContent.setFirstLineIndent(DEFAULT_PARAGRAPH_INDEND);
        paraContent.setSpacingAfter(spacing);
        document.add(paraContent);
    }

    public void addIndexPage() throws DocumentException {
        document.setMargins(ReportConstants.MARGIN_70,
                ReportConstants.MARGIN_70, ReportConstants.MARGIN_80,
                ReportConstants.MARGIN_100);

        pdfWriter.setPageEvent(null);
        document.newPage();

        int beforeStartPageCount = pdfWriter.getPageNumber();
        Paragraph p = new Paragraph(CONTENTS,
                PDFCreationUtils.getGEInspiraMediumFont(26, Font.NORMAL,
                        new BaseColor(84, 141, 212)));
        p.setAlignment(Element.ALIGN_LEFT);
        document.add(p);
        // document.add(Chunk.NEWLINE);
        int subIndexCountNew = 0;
        int prevHeadIndex = 0;
        int subIndexCount = 0;
        for (IndexContent item : smartReportIndex) {
            addIndexItem(item);
            // int subIndexCount = 1;
            if (item.getHeadingIndex() == prevHeadIndex) {
                subIndexCount = subIndexCountNew;
            } else {
                subIndexCount = 1;
            }
            for (Map.Entry<String, Integer> subItems : item.getSubHeading()
                    .entrySet()) {
                prevHeadIndex = item.getHeadingIndex();
                addIndexItem(item, subIndexCount, subItems);
                subIndexCount++;
                subIndexCountNew = subIndexCount;
            }
        }

        indexPageCount = indexPageCount
                + (pdfWriter.getPageNumber() - beforeStartPageCount);
    }

    private void addIndexItem(IndexContent item, int subIndexCount,
            Map.Entry<String, Integer> subItems) throws DocumentException {

        Chunk heading;
        Chunk line;
        Chunk pageNo;

        DottedLineSeparator separator = new DottedLineSeparator();
        Paragraph p = new Paragraph();
        p.setFont(PDFCreationUtils.NORMAL_FONT_14);

        heading = new Chunk(ReportBuilderUtils.appendStrings("      ",
                String.valueOf(item.getHeadingIndex()),
                ReportConstants.DOT, String.valueOf(subIndexCount),
                ReportConstants.SPACE, subItems.getKey().toUpperCase()));
        heading.setAction(PdfAction.gotoLocalPage(
                String.valueOf(subItems.getValue()), false));

        line = new Chunk(separator);
        line.setAction(PdfAction.gotoLocalPage(
                String.valueOf(subItems.getValue()), false));

        pageNo = new Chunk(String.valueOf(subItems.getValue()));
        heading.setAction(PdfAction.gotoLocalPage(
                String.valueOf(subItems.getValue()), false));

        p.add(heading);
        p.add(line);
        p.add(pageNo);

        document.add(p);
    }

    private void addIndexItem(IndexContent item) throws DocumentException {

        DottedLineSeparator separator = new DottedLineSeparator();
        Paragraph p = new Paragraph();
        Chunk heading;
        Chunk line;
        Chunk pageNo;

        if (item.getHeadingLevel() == 0) {
            p.setSpacingBefore(ReportConstants.CONSTANT_5);
            p.setFont(PDFCreationUtils.getGEInspiraMediumFont(16,
                    Font.NORMAL, new BaseColor(84, 141, 212)));
            heading = new Chunk(item.getHeadingString(item.getHeading()));
        } else {
            p.setFont(PDFCreationUtils.getGEInspiraMediumFont(14,
                    Font.NORMAL, new BaseColor(84, 141, 212)));
            heading = new Chunk(
                    "      " + item.getHeadingString(item.getHeading()));
        }

        heading.setAction(PdfAction.gotoLocalPage(
                String.valueOf(item.getPageNumber()), false));
        separator.setLineWidth(0);
        line = new Chunk(separator);

        line.setAction(PdfAction.gotoLocalPage(item.getPageNumberString(),
                false));
        pageNo = new Chunk(item.getPageNumberString(),
                PDFCreationUtils.NORMAL_FONT_CUSTOM_14);
        pageNo.setAction(PdfAction
                .gotoLocalPage(item.getPageNumberString(), false));

        p.add(heading);
        p.add(line);
        p.add(pageNo);

        document.add(p);
    }

    public Map<Pipo, List<PipoPart>> getChildParts(Long eventId) {

        List<Pipo> capitalParts = pipoRepository
                .findByEventIdAndValidationStatusOrderBySequence(eventId,
                        PipoPartValidationStatus.APPROVED);

        Map<Pipo, List<PipoPart>> childPartsWithParentDetyails = new HashMap<>();
        capitalParts.stream().forEach(capPart -> {
            childPartsWithParentDetyails.put(capPart, pipoPartRepository
                    .findByEventIdAndParentIdAndLcdValidationStatusOrderBySequence(
                            eventId, capPart.getId(),
                            LCDValidationStatus.ACCEPTED));
        });
        return childPartsWithParentDetyails;

    }

    private void createFinalCRTFile(File tmpFile, File finalFile, int indexPageCount)
	        throws IOException, DocumentException {
        PdfReader reader = new PdfReader(tmpFile.toString());
		int totalPages = reader.getNumberOfPages();
		
		reader.selectPages(String.format("1, %d, 2-%d", totalPages, totalPages-1, totalPages-1));
		
		PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(
				finalFile));
		 PdfContentByte pagecontent;
		 int pageEndCounter = totalPages-2; 
	        for (int i = 0; i < totalPages; ) {
	            pagecontent = stamper.getOverContent(++i);
	            if(i!=1 && i!=2){ 
	            int pageStartCounter = i-2; 
	            ColumnText.showTextAligned(pagecontent, Element.ALIGN_RIGHT,
	                    new Phrase(String.format("page %s of %s", pageStartCounter, pageEndCounter)), 559, 806, 0);
	            }
	        }
	        stamper.close();
	        reader.close();
	        //deleting tmp file
	    if(tmpFile.delete()){
	    	System.out.println("File deleted successfully");
		}else{
			System.out.println("File is not deleted");
		}
	}
    

}
