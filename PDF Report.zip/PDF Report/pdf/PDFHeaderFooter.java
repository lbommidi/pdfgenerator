package com.ge.partstrack.reportbuilder.pdf;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.partstrack.reportbuilder.utils.ReportConstants;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFHeaderFooter extends PdfPageEventHelper {

    private static final Logger LOGGER = LoggerFactory
            .getLogger(PDFHeaderFooter.class);

    private PdfTemplate total;
    private int indexPageCount;

    public PdfTemplate getTotal() {
        return total;
    }

    public void setTotal(PdfTemplate total) {
        this.total = total;
    }

    public void onOpenDocument(PdfWriter writer, Document document) {
        this.total = writer.getDirectContent().createTemplate(
                ReportConstants.PDF_DIM_WIDTH_30,
                ReportConstants.PDF_DIM_HEIGHT_16);
    }

    public void onEndPage(PdfWriter writer, Document document) {
        Rectangle rect = writer.getBoxSize("art");
        PdfPTable table = new PdfPTable(3);

        try {
            table.setWidths(new int[] { ReportConstants.CELL_WIDTH_24,
                    ReportConstants.CELL_WIDTH_24,
                    ReportConstants.CELL_WIDTH_2 });
            table.setTotalWidth(ReportConstants.FOOTER_TABLE_WIDTH);
            table.setLockedWidth(true);
            table.getDefaultCell()
                    .setFixedHeight(ReportConstants.CELL_HEIGHT_50);
            table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            table.getDefaultCell()
                    .setHorizontalAlignment(Element.ALIGN_RIGHT);
            table.getDefaultCell()
                    .setPaddingTop(ReportConstants.CELL_TOP_PADDING_22);

            PdfPCell cell = new PdfPCell(Image.getInstance(this.total));
            cell.setBorder(Rectangle.NO_BORDER);
            cell.setPaddingTop(ReportConstants.CELL_TOP_PADDING_20);
            table.addCell(cell);
            table.writeSelectedRows(0, -1, ReportConstants.PDF_POS_50,
                    ReportConstants.PDF_POS_80, writer.getDirectContent());

        } catch (DocumentException de) {
            throw new ExceptionConverter(de);
        } catch (Exception e) {
            LOGGER.error(
                    "IOException occured while creating Header footer in PDF"
                            + e.getMessage(),
                    e);
        }
    }

    public void onCloseDocument(PdfWriter writer, Document document) {
        ColumnText.showTextAligned(this.total, Element.ALIGN_LEFT,
                new Phrase(
                        String.valueOf(writer.getPageNumber() - 1
                                - this.indexPageCount),
                        PDFCreationUtils.NORMAL_FONT_TABLE_CELL_12),
                2, 2, 0);
    }

    public int getIndexPageCount() {
        return indexPageCount;
    }

    public void setIndexPageCount(int indexPageCount) {
        this.indexPageCount = indexPageCount;
    }
}
