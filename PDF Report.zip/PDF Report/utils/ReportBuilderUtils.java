package com.ge.partstrack.reportbuilder.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import org.apache.commons.lang3.StringUtils;

public class ReportBuilderUtils {

	public static String getCurrentMethodName() {
		StackTraceElement stackTraceElements[] = (new Throwable())
				.getStackTrace();
		return stackTraceElements[1].toString();
	}

	public static String decodeURL(String data)
			throws UnsupportedEncodingException {
		return URLDecoder.decode(data, "UTF-8");

	}

	public static void writeInputStreamToFile(InputStream fileInputStream,
			String zipPath) throws FileNotFoundException, IOException {
		byte[] bytes = new byte[ReportConstants.BYTE_COUNT_1024];
		OutputStream out = new FileOutputStream(new File(zipPath));
		int read = 0;
		while ((read = fileInputStream.read(bytes)) != -1) {
			out.write(bytes, 0, read);
		}
		out.flush();
		out.close();
	}

	public static String appendStrings(String... stringElement) {
		String appendedString = "";
		for (String string : stringElement) {
			if (StringUtils.isNotEmpty(string)) {
				appendedString = appendedString.concat(string);
			}
		}
		return appendedString;
	}
	
}
