package com.ge.partstrack.reportbuilder.utils;

public class ReportConstants {

	public static final int CONSTANT_5 = 5;
	
	public static final String STR_N = "N";
	
	public static final int TABLE_2_COLUMNS = 2;
	
	public static final int COLUMNS_WIDTH_100 = 100; 
	public static final int CELL_WIDTH_24 = 24;
	public static final int CELL_LEFT_PADDING_40 = 40;
	public static final int CELL_LEFT_PADDING_5 = 5;

	public static final int CELL_TOP_BOTTOM_PADDING_5 = 5;

	public static final String DIR_CUST_REP_PDF_CREATE = "crst_rep_pdf_creation";
	
	public static final int MARGIN_0 = 0;
	public static final int MARGIN_10 = 10;
	public static final int MARGIN_20 = 20;
	public static final int MARGIN_70 = 70;
	public static final int MARGIN_80 = 80;
	public static final int MARGIN_100 = 100;
	public static final int FONT_CONSTANT_24 = 24;
	public static final int FONT_CONSTANT_14 = 14;

	public static final String PDF_EXTENSION = ".pdf";
	public static final String REGEX_PIPE_DELIMITER = "\\|";
	public static final String DOT = ".";
	public static final String UNDERSCORE = "_";
	public static final String PIPE = "|";
	public static final String SPACE = "  ";

	public static final String FILE_INSP_FORM_DATA_ZIP = "inspection_forms_data.zip";
	public static final String FILE_TMP_CRT_PDF = ReportBuilderUtils.appendStrings("tmp_crt_pdf_",
					String.valueOf(System.currentTimeMillis()),
					ReportConstants.PDF_EXTENSION);
	public static final String FILE_CRT_PDF = ReportBuilderUtils.appendStrings(
			"_Event_Report_%s", ReportConstants.PDF_EXTENSION);

	//Index
	public static final String PIPO_SCOPE_LIST = "PIPO SCOPE LIST";
	public static final String TIMERS_COUNTERS = "TIMERS AND COUNTERS";
	
	//Operational data 
	public static final String OPT_DATA_COUNTER = "Operation Data Counter";
	public static final String READING = "Reading";
	public static final String EQUI_OPT_HOURS = "Equivalent Operating Hours (EOH)";
	public static final String OPT_HOURS         = "Operation Hours (OH)";
	public static final String OPT_HOURS_BACKUP = "Operation Hours Backup (OHB)";
	public static final String OPT_STARTS = "Starts (S)";
	public static final String OPT_STARTS_BACKUP = "Starts Backup (SB)";
	public static final String OPT_TRIPS = "Trips (T)";
	public static final String OPT_TRIPS_HIGH = "Trips high (Th)";
	
	//Event Details
	public static final String REPORT_NO = "Report No#";
	public static final String PLANT_NAME = "Plant (Name)";
	public static final String UNIT_NAME         = "Unit (Name)";
	public static final String UNIT_KEY = "Unit Key";
	public static final String EVENT_NAME = "Event Name";
	public static final String INSPECT_CODE = "Inspection Code";
	public static final String OUTAGE_TYPE = "Outage Type";
	public static final String DESCRIPTION = "Description";
	public static final String COUNTRY = "Country";
	public static final String CITY = "City";
	public static final String SYSTEM_ID = "System ID";
	
	// capital parts section details
	public static final String PARTS_IN = "Parts In";
	public static final String PARTS_OUT = "Parts Out";
	public static final String SERIAL_NO = "Serial No";
	public static final String LOCATION_NO = "Location No";
	public static final String IDENT_NO = "Ident No";
	public static final String PART_CONDITION = "Part Condition";
	
	public static final int BYTE_COUNT_1024 = 1024;
	public static final int CELL_WIDTH_2 = 2;
	public static final float CELL_HEIGHT_50 = 50;
	public static final int FOOTER_TABLE_WIDTH = 480;
	public static final int CELL_TOP_PADDING_22 = 22;
	public static final int CELL_TOP_PADDING_20 = 20;
	
	public static final int PDF_POS_50 = 50;
	public static final int PDF_POS_80 = 80;
	
	public static final int PDF_DIM_WIDTH_30 = 30;
	public static final int PDF_DIM_HEIGHT_16 = 16;
	
	public static final int COLOR_CONSTANT_84 = 84;
	public static final int COLOR_CONSTANT_141 = 141;
	public static final int COLOR_CONSTANT_212 = 212;

}
